# EmojiText
Based on UGUI to support emoji system on Text component.
