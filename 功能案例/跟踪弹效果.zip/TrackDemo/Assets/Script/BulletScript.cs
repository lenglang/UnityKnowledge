﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 跟踪导弹脚本.
/// </summary>
public class BulletScript : MonoBehaviour
{
	/// <summary>
	/// 每秒最大可旋转的角度.
	/// </summary>
	private const float MAX_ROTATION = 90;
	
	/// <summary>
	/// 每帧最大可旋转的角度.
	/// </summary>
	private static float MAX_ROTATION_FRAME = MAX_ROTATION / ((float) (Application.targetFrameRate == -1 ? 60 : Application.targetFrameRate));

	/// <summary>
	/// 攻击目标.
	/// </summary>
	public GameObject target;

    void Start()
    {
    }
    
    void Update()
    {
		//转向目标
		float dx = target.transform.position.x - this.transform.position.x;
		float dy = target.transform.position.y - this.transform.position.y;
		float rotationZ = Mathf.Atan2(dy, dx) * 180 / Mathf.PI;
		//得到最终的角度并且确保在 [0, 360) 这个区间内
		rotationZ -= 90;
		rotationZ = MakeSureRightRotation(rotationZ);
		//获取增加的角度
		float originRotationZ = MakeSureRightRotation(this.transform.eulerAngles.z);
		float addRotationZ = rotationZ - originRotationZ;
		//超过 180 度需要修改为负方向的角度
		if(addRotationZ > 180)
		{
			addRotationZ -= 360;
		}
		//不超过每帧最大可旋转的阀值
		addRotationZ = Mathf.Max(-MAX_ROTATION_FRAME, Mathf.Min(MAX_ROTATION_FRAME, addRotationZ));
		//应用旋转
		this.transform.eulerAngles = new Vector3(0, 0, this.transform.eulerAngles.z + addRotationZ);
		//移动
		this.transform.Translate(new Vector3(0, 2.0f * Time.deltaTime, 0));
    }

	/// <summary>
	/// 确保角度在 [0, 360) 这个区间内.
	/// </summary>
	/// <param name="rotation">任意数值的角度.</param>
	/// <returns>对应的在 [0, 360) 这个区间内的角度.</returns>
	private float MakeSureRightRotation(float rotation)
	{
		rotation += 360;
		rotation %= 360;
		return rotation;
	}
}
