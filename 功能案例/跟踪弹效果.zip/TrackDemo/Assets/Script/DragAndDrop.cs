﻿using UnityEngine;
using System.Collections;

/// <summary>
/// 拖拽脚本.
/// </summary>
public class DragAndDrop : MonoBehaviour
{
	bool isCatched = false;

    void Update()
    {
		if(Input.GetMouseButtonDown(0))
		{
			//根据鼠标位置创建一条垂直于屏幕的射线
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			//保存射线信息的结构体
			RaycastHit hit;
			//对射线进行碰撞, 如果存在碰撞
			if(Physics.Raycast(ray, out hit))
			{
				//碰撞到当前对象时
				if(hit.collider.gameObject == this.gameObject)
				{
					//标记为抓取状态
					isCatched = true;
				}
			}
		}

		if(Input.GetMouseButtonUp(0))
		{
			//取消抓取状态
			isCatched = false;
		}

		if(isCatched)
		{
			//获取鼠标点在场景中的位置
			Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			pos.z = 0;
			//设置位置
			this.transform.position = pos;
		}
    }
}
