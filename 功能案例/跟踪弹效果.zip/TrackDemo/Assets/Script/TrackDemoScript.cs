using UnityEngine;
using System.Collections;

/// <summary>
/// 控制脚本.
/// </summary>
public class TrackDemoScript : MonoBehaviour
{
	public GameObject player;

	public GameObject enemy;

	/// <summary>
	/// 开火.
	/// </summary>
    public void Fire()
	{
		GameObject go = Resources.Load<GameObject>("Prefab/Bullet");
		GameObject bullet = Instantiate(go, player.transform.position, Quaternion.identity) as GameObject;
		bullet.GetComponent<BulletScript>().target = enemy;
	}
}
